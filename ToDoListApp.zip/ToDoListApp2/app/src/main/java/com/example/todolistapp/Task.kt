package com.example.todolistapp

data class Task(
    val taskName: String,
    val dueDate: String = "No Date Selected",  // Default value for due date
    val priority: String = "Low"  // Default value for priority
)
