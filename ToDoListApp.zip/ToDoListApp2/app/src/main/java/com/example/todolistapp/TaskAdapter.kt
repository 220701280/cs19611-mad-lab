package com.example.todolistapp

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class TaskAdapter(private val taskList: MutableList<Task>) : RecyclerView.Adapter<TaskAdapter.TaskViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TaskViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_task, parent, false)
        return TaskViewHolder(view)
    }

    override fun onBindViewHolder(holder: TaskViewHolder, position: Int) {
        val task = taskList[position]
        holder.taskName.text = task.taskName
        holder.dueDate.text = "Due Date: ${task.dueDate}"
        holder.priority.text = "Priority: ${task.priority}"

        // Set up the "Completed" button to mark the task as completed or remove it
        holder.btnDelete.setOnClickListener {
            // Optionally remove the task from the list
            taskList.removeAt(position)
            notifyItemRemoved(position)
        }
    }

    override fun getItemCount(): Int = taskList.size

    class TaskViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val taskName: TextView = itemView.findViewById(R.id.textTask)
        val dueDate: TextView = itemView.findViewById(R.id.dueDate)
        val priority: TextView = itemView.findViewById(R.id.priority)
        val btnDelete: Button = itemView.findViewById(R.id.btnDelete) // Reference to the "Completed" button
    }
}
